# AES-GCM-256 RTL update: decrypt + DE2-115 demo

## Added

- `rtl/aes_gcm_256_decrypt.sv`
  - AES-GCM-256 CTR decryption
  - AAD GHASH
  - ciphertext GHASH
  - partial-block zero padding
  - GCM length block
  - received tag verification
  - `auth_valid_o` and calculated tag output
- `rtl/tb_aes_gcm_256_decrypt.sv`
  - NIST zero-key/zero-IV one-block valid-tag test
  - corrupted-tag rejection test
  - AAD + 20-byte partial-final-block test with a different AES-256 key
- `rtl/run_decrypt_sim.sh`
- `fpga_de2_115/`
  - Quartus QPF/QSF/SDC
  - DE2-115 top-level demo
  - button/LED/HEX usage guide

## Changed

- `rtl/aes_gcm_256_encrypt.sv`
  - key loading now uses a one-cycle `LOAD_KEY` pulse followed by `LOAD_KEY_WAIT`.
  - this permits a fresh key expansion on repeated GCM transactions instead of
    accidentally reusing the previous expanded key when the core is started again.
- `rtl/tb_aes_gcm_256.sv`
  - trace condition updated for the added key-wait state.

## Demo behavior

The DE2-115 demo automatically performs:

`plaintext -> AES-GCM encrypt -> ciphertext + tag -> AES-GCM decrypt -> plaintext + tag check`

with the AES-256-GCM known vector:

- ciphertext: `CEA7403D4D606B6E074EC5D3BAF39D18`
- tag: `D0D1C8A799996BF0265B98B5D48AB919`

`SW[1:0]=11` shows `PASS` on the seven-segment displays when all checks pass.

## Verification performed in this package update

- Software AES-GCM cross-check of the NIST vector: PASS
- Software AES-GCM cross-check of the AAD + partial-block vector: PASS
- Structural source checks (balanced module/begin/case/function/task constructs): PASS
- C decrypt reference builds with GCC and accepts the valid NIST tag / rejects the corrupted tag.

A Quartus/iverilog executable was not available in the editing environment, so the
included RTL should still be compiled in your local Quartus/ModelSim setup before board programming.
