# AES-GCM-256 Encrypt + Decrypt demo on DE2-115

This demo uses the existing encrypt RTL plus the new `aes_gcm_256_decrypt.sv` block.
It runs a known one-block AES-256-GCM vector entirely in hardware:

- Key: 256'h0
- IV: 96'h0
- Plaintext: 128'h0
- Expected ciphertext: `CEA7403D4D606B6E074EC5D3BAF39D18`
- Expected tag: `D0D1C8A799996BF0265B98B5D48AB919`

The controller first encrypts the plaintext, captures ciphertext + tag, then feeds them
into the decrypt core. The demo passes only when ciphertext, tag, recovered plaintext,
and authentication all match.

## Board controls

- `KEY[0]`: reset (active low)
- `KEY[1]`: start/restart demo (active low button; edge detected)
- `SW[1:0]`: display select
  - `00`: low 32 bits of ciphertext (HEX should show `BAF39D18`)
  - `01`: low 32 bits of tag (HEX should show `D48AB919`)
  - `10`: low 32 bits of recovered plaintext (`00000000`)
  - `11`: show `PASS` or `FAIL`

## LED status

- `LEDG[8]`: busy
- `LEDG[0]`: demo complete
- `LEDG[1]`: received tag authenticated
- `LEDG[2]`: recovered plaintext correct
- `LEDG[3]`: encrypt ciphertext matches known vector
- `LEDG[4]`: encrypt tag matches known vector
- `LEDR[17]`: completed demo failed (when SW=`11`)

## Quartus

1. Open `aes_gcm_de2_115_demo.qpf` in Quartus.
2. Confirm the device is `EP4CE115F29C7` (Cyclone IV E).
3. Compile the project.
4. Program the generated `.sof` through USB-Blaster.
5. Press `KEY[0]` once to reset, then press `KEY[1]` to run.
6. Set `SW[1:0]=11`; a correct run shows `PASS` and LEDG[0..4] are ON.

The QSF already includes the RTL files, DE2-115 pin assignments, and 3.3-V LVTTL I/O standards.

## Decrypt interface note

`aes_gcm_256_decrypt` streams provisional plaintext before the final tag is known.
Use `auth_valid_o` at `done_o` to decide whether that plaintext may be accepted. For a
security boundary that must never expose unauthenticated plaintext, add a FIFO/RAM after
`data_o` and release it only when `auth_valid_o=1`.
