module aes_gcm_de2_115_demo (
    input  logic        CLOCK_50,
    input  logic [3:0]  KEY,
    input  logic [1:0]  SW,
    output logic [17:0] LEDR,
    output logic [8:0]  LEDG,
    output logic [6:0]  HEX0,
    output logic [6:0]  HEX1,
    output logic [6:0]  HEX2,
    output logic [6:0]  HEX3,
    output logic [6:0]  HEX4,
    output logic [6:0]  HEX5,
    output logic [6:0]  HEX6,
    output logic [6:0]  HEX7
);
    localparam logic [255:0] DEMO_KEY = 256'h0;
    localparam logic [95:0]  DEMO_IV  = 96'h0;
    localparam logic [127:0] DEMO_PT  = 128'h0;
    localparam logic [127:0] EXPECT_CT  = 128'hcea7403d4d606b6e074ec5d3baf39d18;
    localparam logic [127:0] EXPECT_TAG = 128'hd0d1c8a799996bf0265b98b5d48ab919;

    // -----------------------------------------------------------------
    // Synchronize KEY[1] and generate one pulse when it is pressed.
    // KEY[0] is the active-low asynchronous reset button on DE2-115.
    // -----------------------------------------------------------------
    logic key1_meta, key1_sync, key1_prev;
    wire start_button = key1_prev & ~key1_sync;

    always_ff @(posedge CLOCK_50 or negedge KEY[0]) begin
        if (!KEY[0]) begin
            key1_meta <= 1'b1;
            key1_sync <= 1'b1;
            key1_prev <= 1'b1;
        end else begin
            key1_meta <= KEY[1];
            key1_sync <= key1_meta;
            key1_prev <= key1_sync;
        end
    end

    // -----------------------------------------------------------------
    // Encrypt core wiring
    // -----------------------------------------------------------------
    logic enc_start, enc_ready, enc_done;
    logic [127:0] enc_data_i, enc_data_o, enc_tag;
    logic enc_data_val_i, enc_data_ready, enc_data_val_o;

    aes_gcm_256_encrypt u_encrypt (
        .clk(CLOCK_50), .rst_n(KEY[0]),
        .start_i(enc_start), .ready_o(enc_ready), .done_o(enc_done),
        .key_i(DEMO_KEY), .iv_i(DEMO_IV),
        .aad_len_i(64'd0), .pt_len_i(64'd16),
        .data_i(enc_data_i), .data_val_i(enc_data_val_i),
        .data_ready_o(enc_data_ready),
        .data_o(enc_data_o), .data_val_o(enc_data_val_o),
        .tag_o(enc_tag)
    );

    // -----------------------------------------------------------------
    // Decrypt core wiring
    // -----------------------------------------------------------------
    logic dec_start, dec_ready, dec_done;
    logic [127:0] dec_data_i, dec_data_o, dec_tag_calc;
    logic dec_data_val_i, dec_data_ready, dec_data_val_o;
    logic dec_auth_valid;
    logic [127:0] ciphertext_q, tag_q, plaintext_q;

    aes_gcm_256_decrypt u_decrypt (
        .clk(CLOCK_50), .rst_n(KEY[0]),
        .start_i(dec_start), .ready_o(dec_ready), .done_o(dec_done),
        .key_i(DEMO_KEY), .iv_i(DEMO_IV),
        .aad_len_i(64'd0), .ct_len_i(64'd16), .tag_i(tag_q),
        .data_i(dec_data_i), .data_val_i(dec_data_val_i),
        .data_ready_o(dec_data_ready),
        .data_o(dec_data_o), .data_val_o(dec_data_val_o),
        .auth_valid_o(dec_auth_valid), .tag_calc_o(dec_tag_calc)
    );

    typedef enum logic [3:0] {
        DEMO_IDLE,
        ENC_START,
        ENC_WAIT_DATA,
        ENC_CAPTURE,
        ENC_WAIT_DONE,
        DEC_START,
        DEC_WAIT_DATA,
        DEC_CAPTURE,
        DEC_WAIT_DONE,
        DEMO_DONE
    } demo_state_e;

    demo_state_e state_q;
    logic ct_ok_q, tag_ok_q, pt_ok_q, auth_ok_q;
    logic demo_complete_q;

    always_ff @(posedge CLOCK_50 or negedge KEY[0]) begin
        if (!KEY[0]) begin
            state_q         <= DEMO_IDLE;
            enc_start       <= 1'b0;
            enc_data_i      <= 128'h0;
            enc_data_val_i  <= 1'b0;
            dec_start       <= 1'b0;
            dec_data_i      <= 128'h0;
            dec_data_val_i  <= 1'b0;
            ciphertext_q    <= 128'h0;
            tag_q           <= 128'h0;
            plaintext_q     <= 128'h0;
            ct_ok_q         <= 1'b0;
            tag_ok_q        <= 1'b0;
            pt_ok_q         <= 1'b0;
            auth_ok_q       <= 1'b0;
            demo_complete_q <= 1'b0;
        end else begin
            // Pulse-style handshakes are low unless asserted by a state below.
            enc_start      <= 1'b0;
            enc_data_val_i <= 1'b0;
            dec_start      <= 1'b0;
            dec_data_val_i <= 1'b0;

            case (state_q)
                DEMO_IDLE: begin
                    if (start_button) begin
                        ciphertext_q    <= 128'h0;
                        tag_q           <= 128'h0;
                        plaintext_q     <= 128'h0;
                        ct_ok_q         <= 1'b0;
                        tag_ok_q        <= 1'b0;
                        pt_ok_q         <= 1'b0;
                        auth_ok_q       <= 1'b0;
                        demo_complete_q <= 1'b0;
                        state_q         <= ENC_START;
                    end
                end

                ENC_START: begin
                    if (enc_ready) begin
                        enc_start <= 1'b1;
                        state_q   <= ENC_WAIT_DATA;
                    end
                end

                ENC_WAIT_DATA: begin
                    if (enc_data_ready) begin
                        enc_data_i     <= DEMO_PT;
                        enc_data_val_i <= 1'b1;
                        state_q        <= ENC_CAPTURE;
                    end
                end

                ENC_CAPTURE: begin
                    if (enc_data_val_o) begin
                        ciphertext_q <= enc_data_o;
                        ct_ok_q      <= (enc_data_o == EXPECT_CT);
                        state_q      <= ENC_WAIT_DONE;
                    end
                end

                ENC_WAIT_DONE: begin
                    if (enc_done) begin
                        tag_q    <= enc_tag;
                        tag_ok_q <= (enc_tag == EXPECT_TAG);
                        state_q  <= DEC_START;
                    end
                end

                DEC_START: begin
                    if (dec_ready) begin
                        dec_start <= 1'b1;
                        state_q   <= DEC_WAIT_DATA;
                    end
                end

                DEC_WAIT_DATA: begin
                    if (dec_data_ready) begin
                        dec_data_i     <= ciphertext_q;
                        dec_data_val_i <= 1'b1;
                        state_q        <= DEC_CAPTURE;
                    end
                end

                DEC_CAPTURE: begin
                    if (dec_data_val_o) begin
                        plaintext_q <= dec_data_o;
                        state_q     <= DEC_WAIT_DONE;
                    end
                end

                DEC_WAIT_DONE: begin
                    if (dec_done) begin
                        pt_ok_q         <= (plaintext_q == DEMO_PT);
                        auth_ok_q       <= dec_auth_valid;
                        demo_complete_q <= 1'b1;
                        state_q         <= DEMO_DONE;
                    end
                end

                DEMO_DONE: begin
                    if (start_button) begin
                        ciphertext_q    <= 128'h0;
                        tag_q           <= 128'h0;
                        plaintext_q     <= 128'h0;
                        ct_ok_q         <= 1'b0;
                        tag_ok_q        <= 1'b0;
                        pt_ok_q         <= 1'b0;
                        auth_ok_q       <= 1'b0;
                        demo_complete_q <= 1'b0;
                        state_q         <= ENC_START;
                    end
                end

                default: state_q <= DEMO_IDLE;
            endcase
        end
    end

    wire busy = (state_q != DEMO_IDLE) && (state_q != DEMO_DONE);
    wire pass = demo_complete_q && ct_ok_q && tag_ok_q && pt_ok_q && auth_ok_q;

    // LED meaning:
    // LEDG0=demo complete, LEDG1=tag authenticated, LEDG2=plaintext recovered,
    // LEDG3=ciphertext matches NIST vector, LEDG4=generated tag matches NIST,
    // LEDG8=busy. LEDR17 lights if the completed demo failed.
    always @(*) begin
        LEDG = 9'h000;
        LEDG[0] = demo_complete_q;
        LEDG[1] = auth_ok_q;
        LEDG[2] = pt_ok_q;
        LEDG[3] = ct_ok_q;
        LEDG[4] = tag_ok_q;
        LEDG[8] = busy;

        case (SW)
            2'b00: LEDR = ciphertext_q[17:0];
            2'b01: LEDR = tag_q[17:0];
            2'b10: LEDR = plaintext_q[17:0];
            default: begin
                LEDR = 18'h0;
                LEDR[17] = demo_complete_q && !pass;
            end
        endcase
    end

    function automatic logic [6:0] hex7(input logic [3:0] x);
        begin
            // Active-low DE2-115 seven-segment encoding, {g,f,e,d,c,b,a}.
            case (x)
                4'h0: hex7 = 7'b1000000; 4'h1: hex7 = 7'b1111001;
                4'h2: hex7 = 7'b0100100; 4'h3: hex7 = 7'b0110000;
                4'h4: hex7 = 7'b0011001; 4'h5: hex7 = 7'b0010010;
                4'h6: hex7 = 7'b0000010; 4'h7: hex7 = 7'b1111000;
                4'h8: hex7 = 7'b0000000; 4'h9: hex7 = 7'b0010000;
                4'hA: hex7 = 7'b0001000; 4'hB: hex7 = 7'b0000011;
                4'hC: hex7 = 7'b1000110; 4'hD: hex7 = 7'b0100001;
                4'hE: hex7 = 7'b0000110; default: hex7 = 7'b0001110;
            endcase
        end
    endfunction

    logic [31:0] display_word;
    always @(*) begin
        case (SW)
            2'b00: display_word = ciphertext_q[31:0];
            2'b01: display_word = tag_q[31:0];
            2'b10: display_word = plaintext_q[31:0];
            default: display_word = 32'h0;
        endcase

        HEX0 = hex7(display_word[3:0]);
        HEX1 = hex7(display_word[7:4]);
        HEX2 = hex7(display_word[11:8]);
        HEX3 = hex7(display_word[15:12]);
        HEX4 = hex7(display_word[19:16]);
        HEX5 = hex7(display_word[23:20]);
        HEX6 = hex7(display_word[27:24]);
        HEX7 = hex7(display_word[31:28]);

        // SW=11 gives a human-readable final status on HEX3..HEX0.
        if (SW == 2'b11) begin
            HEX7 = 7'b1111111;
            HEX6 = 7'b1111111;
            HEX5 = 7'b1111111;
            HEX4 = 7'b1111111;
            if (!demo_complete_q) begin
                HEX3 = 7'b1111111;
                HEX2 = 7'b1111111;
                HEX1 = 7'b1111111;
                HEX0 = 7'b1111111;
            end else if (pass) begin
                // PASS
                HEX3 = 7'b0001100; // P
                HEX2 = 7'b0001000; // A
                HEX1 = 7'b0010010; // S
                HEX0 = 7'b0010010; // S
            end else begin
                // FAIL (I is displayed as '1')
                HEX3 = 7'b0001110; // F
                HEX2 = 7'b0001000; // A
                HEX1 = 7'b1111001; // I/1
                HEX0 = 7'b1000111; // L
            end
        end
    end
endmodule
