module aes_gcm_256_decrypt (
    input  logic         clk,
    input  logic         rst_n,

    // Control
    input  logic         start_i,
    output logic         ready_o,
    output logic         done_o,

    // Key, IV, lengths, and received authentication tag
    input  logic [255:0] key_i,
    input  logic [95:0]  iv_i,
    input  logic [63:0]  aad_len_i,
    input  logic [63:0]  ct_len_i,
    input  logic [127:0] tag_i,

    // Input data stream: AAD first, then ciphertext
    input  logic [127:0] data_i,
    input  logic         data_val_i,
    output logic         data_ready_o,

    // Plaintext stream. The plaintext is provisional until done_o=1 and
    // auth_valid_o=1. A system requiring "authenticate before release" must
    // buffer this stream externally and commit it only after auth_valid_o.
    output logic [127:0] data_o,
    output logic         data_val_o,

    // Authentication result
    output logic         auth_valid_o,
    output logic [127:0] tag_calc_o
);

    typedef enum logic [3:0] {
        IDLE,
        LOAD_KEY,
        LOAD_KEY_WAIT,
        CALC_H,
        AAD_INPUT,
        AAD_HASH,
        CT_CTR_INC,
        CT_CTR_ENC,
        CT_WAIT_DATA,
        CT_HASH,
        CALC_L,
        CALC_TAG_ENC,
        TAG_CHECK,
        FINISH
    } state_e;

    state_e state_q, state_d;

    logic [255:0] key_q, key_d;
    logic [95:0]  iv_q, iv_d;
    logic [63:0]  aad_len_q, aad_len_d;
    logic [63:0]  ct_len_q, ct_len_d;
    logic [127:0] tag_q, tag_d;

    logic [63:0]  aad_blocks_q, aad_blocks_d;
    logic [63:0]  ct_blocks_q, ct_blocks_d;
    logic [63:0]  blk_cnt_q, blk_cnt_d;

    logic [127:0] H_q, H_d;
    logic [127:0] J0_q, J0_d;
    logic [127:0] Y_q, Y_d;
    logic [127:0] ctr_q, ctr_d;
    logic [127:0] keystream_q, keystream_d;
    logic [127:0] din_reg_q, din_reg_d;
    logic [127:0] EJ0_q, EJ0_d;
    logic         auth_valid_q, auth_valid_d;
    logic [127:0] pt_full;

    logic         aes_load_key;
    logic         aes_start;
    logic [127:0] aes_data_in;
    logic         aes_key_ready;
    logic         aes_ready;
    logic         aes_done;
    logic [127:0] aes_data_out;

    aes_256_core aes_core_inst (
        .clk(clk),
        .rst_n(rst_n),
        .load_key_i(aes_load_key),
        .key_i(key_q),
        .key_ready_o(aes_key_ready),
        .start_i(aes_start),
        .ready_o(aes_ready),
        .done_o(aes_done),
        .data_i(aes_data_in),
        .data_o(aes_data_out)
    );

    logic         gf_start;
    logic [127:0] gf_x;
    logic [127:0] gf_y;
    logic         gf_ready;
    logic         gf_done;
    logic [127:0] gf_z;

    gf_mul_128 gf_mul_inst (
        .clk(clk),
        .rst_n(rst_n),
        .start_i(gf_start),
        .x_i(gf_x),
        .y_i(gf_y),
        .ready_o(gf_ready),
        .done_o(gf_done),
        .z_o(gf_z)
    );

    function automatic logic [127:0] pad_block(
        input logic [127:0] val,
        input logic [3:0]   num_bytes
    );
        logic [127:0] padded;
        begin
            padded = val;
            if (num_bytes != 4'd0) begin
                for (int i = 0; i < 16; i++) begin
                    if (i >= num_bytes) begin
                        padded[127 - 8*i -: 8] = 8'h00;
                    end
                end
            end
            return padded;
        end
    endfunction

    always @(*) begin
        pt_full       = 128'h0;
        state_d       = state_q;
        key_d         = key_q;
        iv_d          = iv_q;
        aad_len_d     = aad_len_q;
        ct_len_d      = ct_len_q;
        tag_d         = tag_q;
        aad_blocks_d  = aad_blocks_q;
        ct_blocks_d   = ct_blocks_q;
        blk_cnt_d     = blk_cnt_q;
        H_d           = H_q;
        J0_d          = J0_q;
        Y_d           = Y_q;
        ctr_d         = ctr_q;
        keystream_d   = keystream_q;
        din_reg_d     = din_reg_q;
        EJ0_d         = EJ0_q;
        auth_valid_d  = auth_valid_q;

        ready_o       = 1'b0;
        done_o        = 1'b0;
        data_ready_o  = 1'b0;
        data_o        = 128'h0;
        data_val_o    = 1'b0;

        aes_load_key  = 1'b0;
        aes_start     = 1'b0;
        aes_data_in   = 128'h0;
        gf_start      = 1'b0;
        gf_x          = 128'h0;
        gf_y          = 128'h0;

        case (state_q)
            IDLE: begin
                ready_o = 1'b1;
                if (start_i) begin
                    key_d        = key_i;
                    iv_d         = iv_i;
                    aad_len_d    = aad_len_i;
                    ct_len_d     = ct_len_i;
                    tag_d        = tag_i;
                    aad_blocks_d = (aad_len_i == 64'd0) ? 64'd0 : (aad_len_i + 64'd15) >> 4;
                    ct_blocks_d  = (ct_len_i  == 64'd0) ? 64'd0 : (ct_len_i  + 64'd15) >> 4;
                    auth_valid_d = 1'b0;
                    state_d      = LOAD_KEY;
                end
            end

            LOAD_KEY: begin
                // Force a fresh expansion once per GCM transaction.
                aes_load_key = 1'b1;
                state_d      = LOAD_KEY_WAIT;
            end

            LOAD_KEY_WAIT: begin
                if (aes_key_ready) begin
                    state_d = CALC_H;
                end
            end

            CALC_H: begin
                aes_data_in = 128'h0;
                if (aes_ready) begin
                    aes_start = 1'b1;
                end
                if (aes_done) begin
                    H_d  = aes_data_out;
                    J0_d = {iv_q, 32'd1};
                    Y_d  = 128'h0;
                    if (aad_blocks_q > 64'd0) begin
                        blk_cnt_d = 64'd0;
                        state_d   = AAD_INPUT;
                    end else if (ct_blocks_q > 64'd0) begin
                        blk_cnt_d = 64'd0;
                        ctr_d     = {iv_q, 32'd1};
                        state_d   = CT_CTR_INC;
                    end else begin
                        state_d = CALC_L;
                    end
                end
            end

            AAD_INPUT: begin
                data_ready_o = 1'b1;
                if (data_val_i) begin
                    if ((blk_cnt_q == aad_blocks_q - 64'd1) && (aad_len_q[3:0] != 4'd0)) begin
                        din_reg_d = pad_block(data_i, aad_len_q[3:0]);
                    end else begin
                        din_reg_d = data_i;
                    end
                    state_d = AAD_HASH;
                end
            end

            AAD_HASH: begin
                gf_x = Y_q ^ din_reg_q;
                gf_y = H_q;
                if (gf_ready) begin
                    gf_start = 1'b1;
                end
                if (gf_done) begin
                    Y_d = gf_z;
                    if (blk_cnt_q == aad_blocks_q - 64'd1) begin
                        if (ct_blocks_q > 64'd0) begin
                            blk_cnt_d = 64'd0;
                            ctr_d     = J0_q;
                            state_d   = CT_CTR_INC;
                        end else begin
                            state_d = CALC_L;
                        end
                    end else begin
                        blk_cnt_d = blk_cnt_q + 64'd1;
                        state_d   = AAD_INPUT;
                    end
                end
            end

            CT_CTR_INC: begin
                ctr_d   = {ctr_q[127:32], ctr_q[31:0] + 32'd1};
                state_d = CT_CTR_ENC;
            end

            CT_CTR_ENC: begin
                aes_data_in = ctr_q;
                if (aes_ready) begin
                    aes_start = 1'b1;
                end
                if (aes_done) begin
                    keystream_d = aes_data_out;
                    state_d     = CT_WAIT_DATA;
                end
            end

            CT_WAIT_DATA: begin
                data_ready_o = 1'b1;
                if (data_val_i) begin
                    // GCM authenticates the ciphertext, not the recovered plaintext.
                    if ((blk_cnt_q == ct_blocks_q - 64'd1) && (ct_len_q[3:0] != 4'd0)) begin
                        din_reg_d = pad_block(data_i, ct_len_q[3:0]);
                    end else begin
                        din_reg_d = data_i;
                    end

                    pt_full     = keystream_q ^ data_i;
                    data_val_o  = 1'b1;
                    if ((blk_cnt_q == ct_blocks_q - 64'd1) && (ct_len_q[3:0] != 4'd0)) begin
                        data_o = pad_block(pt_full, ct_len_q[3:0]);
                    end else begin
                        data_o = pt_full;
                    end
                    state_d = CT_HASH;
                end
            end

            CT_HASH: begin
                gf_x = Y_q ^ din_reg_q;
                gf_y = H_q;
                if (gf_ready) begin
                    gf_start = 1'b1;
                end
                if (gf_done) begin
                    Y_d = gf_z;
                    if (blk_cnt_q == ct_blocks_q - 64'd1) begin
                        state_d = CALC_L;
                    end else begin
                        blk_cnt_d = blk_cnt_q + 64'd1;
                        state_d   = CT_CTR_INC;
                    end
                end
            end

            CALC_L: begin
                // GCM length block = bitlen(AAD) || bitlen(ciphertext)
                gf_x = Y_q ^ {aad_len_q[60:0], 3'b0, ct_len_q[60:0], 3'b0};
                gf_y = H_q;
                if (gf_ready) begin
                    gf_start = 1'b1;
                end
                if (gf_done) begin
                    Y_d     = gf_z;
                    state_d = CALC_TAG_ENC;
                end
            end

            CALC_TAG_ENC: begin
                aes_data_in = J0_q;
                if (aes_ready) begin
                    aes_start = 1'b1;
                end
                if (aes_done) begin
                    EJ0_d   = aes_data_out;
                    state_d = TAG_CHECK;
                end
            end

            TAG_CHECK: begin
                // Reduction-XOR comparison has no data-dependent early exit.
                auth_valid_d = ~|(tag_q ^ (Y_q ^ EJ0_q));
                state_d      = FINISH;
            end

            FINISH: begin
                done_o  = 1'b1;
                state_d = IDLE;
            end

            default: state_d = IDLE;
        endcase
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state_q       <= IDLE;
            key_q         <= 256'h0;
            iv_q          <= 96'h0;
            aad_len_q     <= 64'h0;
            ct_len_q      <= 64'h0;
            tag_q         <= 128'h0;
            aad_blocks_q  <= 64'h0;
            ct_blocks_q   <= 64'h0;
            blk_cnt_q     <= 64'h0;
            H_q           <= 128'h0;
            J0_q          <= 128'h0;
            Y_q           <= 128'h0;
            ctr_q         <= 128'h0;
            keystream_q   <= 128'h0;
            din_reg_q     <= 128'h0;
            EJ0_q         <= 128'h0;
            auth_valid_q  <= 1'b0;
        end else begin
            state_q       <= state_d;
            key_q         <= key_d;
            iv_q          <= iv_d;
            aad_len_q     <= aad_len_d;
            ct_len_q      <= ct_len_d;
            tag_q         <= tag_d;
            aad_blocks_q  <= aad_blocks_d;
            ct_blocks_q   <= ct_blocks_d;
            blk_cnt_q     <= blk_cnt_d;
            H_q           <= H_d;
            J0_q          <= J0_d;
            Y_q           <= Y_d;
            ctr_q         <= ctr_d;
            keystream_q   <= keystream_d;
            din_reg_q     <= din_reg_d;
            EJ0_q         <= EJ0_d;
            auth_valid_q  <= auth_valid_d;
        end
    end

    assign auth_valid_o = auth_valid_q;
    assign tag_calc_o   = Y_q ^ EJ0_q;

endmodule
