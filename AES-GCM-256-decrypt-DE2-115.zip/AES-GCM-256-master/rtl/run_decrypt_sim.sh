#!/usr/bin/env bash
set -euo pipefail
iverilog -g2012 -s tb_aes_gcm_256_decrypt \
  -o sim_decrypt.out \
  aes_sbox.sv aes_key_expand_256.sv aes_256_core.sv gf_mul_128.sv \
  aes_gcm_256_decrypt.sv tb_aes_gcm_256_decrypt.sv
vvp sim_decrypt.out
