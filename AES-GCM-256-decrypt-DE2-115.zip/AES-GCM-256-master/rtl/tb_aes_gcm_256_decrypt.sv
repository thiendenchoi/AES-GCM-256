`timescale 1ns/1ps

module tb_aes_gcm_256_decrypt;
    logic         clk;
    logic         rst_n;
    logic         start;
    logic         ready;
    logic         done;
    logic [255:0] key;
    logic [95:0]  iv;
    logic [63:0]  aad_len;
    logic [63:0]  ct_len;
    logic [127:0] tag_in;
    logic [127:0] data_in;
    logic         data_val_in;
    logic         data_ready;
    logic [127:0] data_out;
    logic         data_val_out;
    logic         auth_valid;
    logic [127:0] tag_calc;

    integer errors;
    logic [127:0] pt0, pt1;

    aes_gcm_256_decrypt dut (
        .clk(clk),
        .rst_n(rst_n),
        .start_i(start),
        .ready_o(ready),
        .done_o(done),
        .key_i(key),
        .iv_i(iv),
        .aad_len_i(aad_len),
        .ct_len_i(ct_len),
        .tag_i(tag_in),
        .data_i(data_in),
        .data_val_i(data_val_in),
        .data_ready_o(data_ready),
        .data_o(data_out),
        .data_val_o(data_val_out),
        .auth_valid_o(auth_valid),
        .tag_calc_o(tag_calc)
    );

    initial begin
        clk = 1'b0;
        forever #10 clk = ~clk; // 50 MHz
    end

    task automatic pulse_start;
        begin
            wait (ready === 1'b1);
            @(posedge clk); #1;
            start = 1'b1;
            @(posedge clk); #1;
            start = 1'b0;
        end
    endtask

    task automatic send_block(input logic [127:0] block);
        begin
            wait (data_ready === 1'b1);
            @(posedge clk); #1;
            data_in     = block;
            data_val_in = 1'b1;
            @(posedge clk); #1;
            data_val_in = 1'b0;
        end
    endtask

    task automatic expect_pt_block(input logic [127:0] expected, input integer index);
        begin
            wait (data_val_out === 1'b1);
            if (data_out !== expected) begin
                $display("[ERROR] PT block %0d mismatch. got=%h expected=%h", index, data_out, expected);
                errors = errors + 1;
            end else begin
                $display("[PASS ] PT block %0d = %h", index, data_out);
            end
        end
    endtask

    initial begin
        errors      = 0;
        rst_n       = 0;
        start       = 0;
        key         = '0;
        iv          = '0;
        aad_len     = 0;
        ct_len      = 0;
        tag_in      = '0;
        data_in     = '0;
        data_val_in = 0;

        $dumpfile("tb_aes_gcm_256_decrypt.vcd");
        $dumpvars(0, tb_aes_gcm_256_decrypt);

        repeat (3) @(posedge clk);
        rst_n = 1'b1;
        repeat (2) @(posedge clk);

        // -------------------------------------------------------------
        // Test 1: NIST SP 800-38D AES-256 GCM, zero key/IV/PT, 16 bytes
        // C = CEA7403D4D606B6E074EC5D3BAF39D18
        // T = D0D1C8A799996BF0265B98B5D48AB919
        // -------------------------------------------------------------
        $display("\n[TEST 1] Valid NIST one-block decrypt");
        key     = 256'h0;
        iv      = 96'h0;
        aad_len = 64'd0;
        ct_len  = 64'd16;
        tag_in  = 128'hd0d1c8a799996bf0265b98b5d48ab919;
        pulse_start();
        fork
            send_block(128'hcea7403d4d606b6e074ec5d3baf39d18);
            expect_pt_block(128'h0, 0);
        join
        wait (done === 1'b1);
        if (auth_valid !== 1'b1) begin
            $display("[ERROR] Valid tag was rejected. tag_calc=%h", tag_calc);
            errors = errors + 1;
        end else begin
            $display("[PASS ] Authentication accepted. tag_calc=%h", tag_calc);
        end
        @(posedge clk);

        // -------------------------------------------------------------
        // Test 2: same ciphertext but one-bit-corrupted authentication tag
        // Plaintext is provisional; auth_valid MUST be 0.
        // -------------------------------------------------------------
        $display("\n[TEST 2] Tampered tag must be rejected");
        tag_in = 128'hd0d1c8a799996bf0265b98b5d48ab918;
        pulse_start();
        fork
            send_block(128'hcea7403d4d606b6e074ec5d3baf39d18);
            expect_pt_block(128'h0, 0);
        join
        wait (done === 1'b1);
        if (auth_valid !== 1'b0) begin
            $display("[ERROR] Tampered tag was accepted!");
            errors = errors + 1;
        end else begin
            $display("[PASS ] Tampered tag rejected as expected.");
        end
        @(posedge clk);

        // -------------------------------------------------------------
        // Test 3: AAD + partial final ciphertext block (20-byte plaintext)
        // Vector generated with a standard AESGCM implementation.
        // AAD = ASCII "AADDemo" (7 bytes), aligned to MSB of the input block.
        // -------------------------------------------------------------
        $display("\n[TEST 3] AAD + partial final block + new key");
        key     = 256'h000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f;
        iv      = 96'h000102030405060708090a0b;
        aad_len = 64'd7;
        ct_len  = 64'd20;
        tag_in  = 128'h09d9134706e522b2247beea095c0ea15;
        pulse_start();

        // AAD block first
        send_block(128'h41414444656d6f000000000000000000);

        // Ciphertext block 0 and plaintext check
        fork
            send_block(128'h4703d418c1e0c41c85489d80bde47662);
            expect_pt_block(128'h000102030405060708090a0b0c0d0e0f, 0);
        join

        // Ciphertext block 1: only first 4 bytes are valid
        fork
            send_block(128'h93c79527000000000000000000000000);
            expect_pt_block(128'h10111213000000000000000000000000, 1);
        join

        wait (done === 1'b1);
        if (auth_valid !== 1'b1) begin
            $display("[ERROR] Partial/AAD vector rejected. tag_calc=%h", tag_calc);
            errors = errors + 1;
        end else begin
            $display("[PASS ] Partial/AAD vector authenticated. tag_calc=%h", tag_calc);
        end

        #100;
        if (errors == 0) begin
            $display("\n============================================================");
            $display("  AES-GCM-256 DECRYPT TESTS PASSED");
            $display("============================================================");
        end else begin
            $display("\n============================================================");
            $display("  AES-GCM-256 DECRYPT TESTS FAILED: %0d error(s)", errors);
            $display("============================================================");
            $fatal(1);
        end
        $finish;
    end
endmodule
